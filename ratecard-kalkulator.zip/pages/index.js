import RateCardCalculator from "../components/RateCardCalculator";
import "../styles/globals.css";

export default function Home() {
  return <RateCardCalculator />;
}
