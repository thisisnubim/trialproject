
import { useState } from "react";

export default function RateCardCalculator() {
  const [follower, setFollower] = useState("");
  const [engagement, setEngagement] = useState("");
  const [avgView, setAvgView] = useState("");
  const [rate, setRate] = useState(null);

  const calculateRate = () => {
    const f = parseInt(follower.replace(/\D/g, "")) || 0;
    const e = parseFloat(engagement) || 0;
    const v = parseInt(avgView.replace(/\D/g, "")) || 0;
    const result = Math.round((f * 10 + v * 5) * (e / 100));
    setRate(result);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 p-4">
      <div className="bg-white shadow-2xl rounded-2xl p-8 w-full max-w-xl">
        <h1 className="text-2xl font-bold mb-6 text-center text-gray-800">Kalkulator Rate Card Kreator</h1>

        <div className="mb-4">
          <label className="block text-gray-700 font-medium mb-1">Jumlah Follower</label>
          <input
            type="text"
            value={follower}
            onChange={(e) => setFollower(e.target.value)}
            placeholder="Contoh: 100000"
            className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div className="mb-4">
          <label className="block text-gray-700 font-medium mb-1">Engagement Rate (%)</label>
          <input
            type="text"
            value={engagement}
            onChange={(e) => setEngagement(e.target.value)}
            placeholder="Contoh: 2.5"
            className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div className="mb-6">
          <label className="block text-gray-700 font-medium mb-1">Rata-rata View</label>
          <input
            type="text"
            value={avgView}
            onChange={(e) => setAvgView(e.target.value)}
            placeholder="Contoh: 5000"
            className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <button
          onClick={calculateRate}
          className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition duration-300"
        >
          Hitung Rate Card
        </button>

        {rate !== null && (
          <div className="mt-6 text-center">
            <p className="text-gray-700 text-lg">Estimasi Rate Card:</p>
            <p className="text-2xl font-bold text-green-600">Rp {rate.toLocaleString("id-ID")}</p>
          </div>
        )}
      </div>
    </div>
  );
}
